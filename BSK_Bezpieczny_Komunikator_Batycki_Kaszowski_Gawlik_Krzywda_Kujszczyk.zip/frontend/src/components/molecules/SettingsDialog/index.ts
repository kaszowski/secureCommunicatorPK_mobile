import SettingsDialog from './SettingsDialog';

export { SettingsDialog };
